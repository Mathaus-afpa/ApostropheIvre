import org.json.JSONException;
import org.json.JSONObject;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
/**
 * [AuteurDAO] - class
 * @author Mathaus
 */
public class AuteurDAO {
	// Instance unique
	private static DAO dao() { return DAOinstance.INSTANCE; }
	private static class DAOinstance { private static final DAO INSTANCE = new DAO(); }
	// Classe interne qui implémente l'interface IDAO
	private static final class DAO implements IDAO<Auteur> {
		@Override
		public Auteur create(String fromJson) throws DaoException, ModelException {
			Auteur nouvelAuteur;
			try {
				// A partir du json
				JSONObject json = new JSONObject(fromJson);
				if (!Auteur.ValiderJson(json)) throw new JsonException(JsonException.JSON_INCORRECT);
				nouvelAuteur = new Auteur();
				nouvelAuteur.setNom(json.getString(Auteur.JSON_NOM));
				nouvelAuteur.setPrenom(json.getString(Auteur.JSON_PRENOM));
				nouvelAuteur.setUrl(json.getString(Auteur.JSON_URL));
				// Requete
				Connection connectionBDD = BDDservice.getInstance().getConnection();
				PreparedStatement requetePreparee = AuteurRequetes.Insert(connectionBDD, nouvelAuteur);
				int idNouvelAuteur = requetePreparee.executeUpdate();
				nouvelAuteur.setId(idNouvelAuteur);
			} catch (JSONException | SQLException | JsonException e) {
				String message = "AuteurDAO.create() : " + e.getClass().getSimpleName();
				throw new DaoException(message);
			}
			if (!maintenirConnection) BDDservice.getInstance().closeConnection(); // pour les requetes multiples, ou fermer la connection
			if (Auteur.ValiderAuteur(nouvelAuteur)) {
				chargerAuteurs = true;  // sert a indiquer une modification de la base
				AUTEURS.put(nouvelAuteur.getId(), nouvelAuteur); // permet d'eviter une requete findAll
				return nouvelAuteur;
			} else throw new ModelException(ModelException.INSTANCE_INVALIDE);
		}
		@Override
		public Auteur find(int id) throws DaoException {
			Auteur auteur = null;
			if (forcerRequete) { // depuis la base de donnee
				try {
					Connection connectionBDD = BDDservice.getInstance().getConnection();
					PreparedStatement requetePreparee = AuteurRequetes.SelectById(connectionBDD, id);
					ResultSet reponse = requetePreparee.executeQuery();
					if (reponse.next()) {
						auteur = new Auteur();
						LireAuteur(reponse, auteur);
					}
				} catch (SQLException | ModelException e) {
					String message = "AuteurDAO.find() : " + e.getClass().getSimpleName();
					throw new DaoException(message);
				}
				if (!maintenirConnection) BDDservice.getInstance().closeConnection(); // pour les requetes multiples, ou fermer la connection
			} else { auteur = AUTEURS.get(id); } // depuis AUTEURS
			return auteur;
		}
		@Override
		public List<Auteur> findAll() throws DaoException {
			if (forcerRequete) { // depuis la base de donnee
				AUTEURS.clear();
				try {
					Connection connectionBDD = BDDservice.getInstance().getConnection();
					Statement requete = connectionBDD.createStatement();
					ResultSet reponse = requete.executeQuery(AuteurRequetes.SELECT_ALL);
					while (reponse.next()) {
						Auteur auteur = new Auteur();
						LireAuteur(reponse, auteur);
					}
				} catch (SQLException | ModelException e) {
					String message = "AuteurDAO.findAll() : " + e.getClass().getSimpleName();
					throw new DaoException(message);
				}
				if (!maintenirConnection) BDDservice.getInstance().closeConnection(); // pour les requetes multiples, ou fermer la connection
			}
			return new ArrayList<>(AUTEURS.values());
		}

		private void LireAuteur(ResultSet reponse, Auteur auteur) throws SQLException, ModelException {
			auteur.setId(reponse.getInt(CHAMPS_ID));
			auteur.setNom(reponse.getString(CHAMPS_NOM));
			auteur.setPrenom(reponse.getString(CHAMPS_PRENOM));
			auteur.setUrl(reponse.getString(CHAMPS_URL));
			if (Auteur.ValiderAuteur(auteur)) { AUTEURS.put(auteur.getId(), auteur); }
			else { throw new ModelException(ModelException.INSTANCE_INVALIDE); }
		}

		@Override
		public Auteur update(String fromJson) throws DaoException {
			Auteur auteur;
			try {
				// A partir du json
				JSONObject json = new JSONObject(fromJson);
				if (!Auteur.ValiderJson(json) && json.has(Auteur.JSON_ID)) throw new JsonException(JsonException.JSON_INCORRECT);
				auteur = AUTEURS.get(json.getInt(Auteur.JSON_ID));
				auteur.setNom(json.getString(Auteur.JSON_NOM));
				auteur.setPrenom(json.getString(Auteur.JSON_PRENOM));
				auteur.setUrl(json.getString(Auteur.JSON_URL));
				if (Auteur.ValiderAuteur(auteur)) { AUTEURS.put(auteur.getId(), auteur);
				} else throw new ModelException(ModelException.INSTANCE_INVALIDE);
				// Requete
				Connection connectionBDD = BDDservice.getInstance().getConnection();
				PreparedStatement requetePreparee = AuteurRequetes.Update(connectionBDD, auteur);
				int lignesModifiees = requetePreparee.executeUpdate();
				if (lignesModifiees != 1) { throw new DaoException(DaoException.DONNEE_INVALIDE); }
				else { chargerAuteurs = true; } // sert en cas de nouyvelle modification de la base
			} catch (JSONException | SQLException | JsonException | ModelException e) {
				String message = "AuteurDAO.update() : " + e.getClass().getSimpleName();
				throw new DaoException(message);
			}
			if (!maintenirConnection) BDDservice.getInstance().closeConnection(); // pour les requetes multiples, ou fermer la connection
			return auteur;
		}
		@Override
		public boolean delete(int id) throws DaoException {
			Auteur auteur = AUTEURS.get(id);
			if (auteur == null) return false;
			else {
				try {
					Connection connectionBDD = BDDservice.getInstance().getConnection();
					PreparedStatement requetePreparee = AuteurRequetes.Delete(connectionBDD, id);
					int lignesSupprimees = requetePreparee.executeUpdate();
					if (lignesSupprimees == 1)  AUTEURS.remove(id);
				} catch (SQLException e) {
					String message = "AuteurDAO.delete() : " + e.getClass().getSimpleName();
					throw new DaoException(message);
				}
				if (!maintenirConnection) BDDservice.getInstance().closeConnection(); // pour les requetes multiples, ou fermer la connection
				return true;
			}
		}
	}
	// Constructeur privé pour empêcher l'instanciation
	private AuteurDAO() {}

	public static boolean isMaintenirConnection() {
		return maintenirConnection;
	}

	public static void setMaintenirConnection(boolean maintenirConnection) {
		AuteurDAO.maintenirConnection = maintenirConnection;
	}

	public static boolean isForcerRequete() {
		return forcerRequete;
	}

	public static void setForcerRequete(boolean forcerRequete) {
		AuteurDAO.forcerRequete = forcerRequete;
	}

	private static boolean maintenirConnection = false;
	private static boolean forcerRequete = false;
	private static boolean chargerAuteurs = true;
	private final static String CHAMPS_ID = "aut_id";
	private final static String CHAMPS_NOM = "aut_nom";
	private final static String CHAMPS_PRENOM = "aut_prenom";
	private final static String CHAMPS_URL = "aut_photo";
	private final static Map<Integer, Auteur> AUTEURS = new ConcurrentHashMap<>();
	// Méthode d'accès à l'instance unique, thread-safe et paresseuse
	// Méthodes statiques qui délèguent les appels à l'instance interne
	public static Auteur creerAuteur(String fromJson) {
        try { return dao().create(fromJson); }
		catch (DaoException | ModelException e) {  Log.error(e.getMessage(), e.getCause()); }
		return null;
    }
	public static Auteur recupererAuteur(int id) {
        try { return dao().find(id); }
		catch (DaoException e) {  Log.error(e.getMessage(), e.getCause()); }
		return null;
    }
	public static Auteur mettreAJourAuteur(String fromJson) {
		try { return dao().update(fromJson); }
		catch (DaoException e) {  Log.error(e.getMessage(), e.getCause()); }
		return null;
	}
	public static boolean supprimerAuteur(int id) {
		try { return dao().delete(id); }
		catch (DaoException e) {  Log.error(e.getMessage(), e.getCause()); }
		return false;
	}
}