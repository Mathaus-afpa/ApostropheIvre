import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * [AuteurRequetes] - class
 * @author Mathaus
 */
public class AuteurRequetes {
	private AuteurRequetes() {}
	public static final String INSERT = "INSERT INTO AUTEUR (aut_nom, aut_prenom, aut_photo) VALUES (?, ?, ?)";
	public static final PreparedStatement Insert(Connection connection, Auteur auteur) throws SQLException {
		if (Auteur.ValiderAuteur(auteur)) {
			PreparedStatement requetePreparee = connection.prepareStatement(AuteurRequetes.INSERT);
			requetePreparee.setString(1, auteur.getNom());			//aut_nom
			requetePreparee.setString(2, auteur.getPrenom());		//aut_prenom
			requetePreparee.setString(3, auteur.getUrl());			//aut_photo
			return requetePreparee;
		} else {
			// todo new Exception
			throw new SQLException();
		}
	}
	public static final String SELECT_ONE = "SELECT aut_id, aut_nom, aut_prenom, aut_photo FROM AUTEUR WHERE aut_id = ?";
	public static final PreparedStatement SelectById(Connection connection, int id) throws SQLException {
		PreparedStatement requetePreparee = connection.prepareStatement(AuteurRequetes.SELECT_ONE);
		requetePreparee.setInt(1, id);
		return requetePreparee;
	}
	public static final String SELECT_ALL = "SELECT aut_id, aut_nom, aut_prenom, aut_photo FROM AUTEUR";
	public static final String UPDATE = "UPDATE AUTEUR SET aut_nom = ?, aut_prenom = ?, aut_photo = ? WHERE aut_id = ?";
	public static final PreparedStatement Update(Connection connection, Auteur auteur) throws SQLException {
		if (Auteur.ValiderAuteur(auteur)) {
			PreparedStatement requetePreparee = connection.prepareStatement(AuteurRequetes.UPDATE);
			requetePreparee.setString(1, auteur.getNom());			//aut_nom
			requetePreparee.setString(2, auteur.getPrenom());		//aut_prenom
			requetePreparee.setString(3, auteur.getUrl());			//aut_photo
			requetePreparee.setInt(4, auteur.getId());				//aut_id
			return requetePreparee;
		} else {
			// todo new Exception
			throw new SQLException();
		}
	}
	public static final String DELETE = "DELETE FROM AUTEUR WHERE aut_nom = ?";
	public static final PreparedStatement Delete(Connection connection, int id) throws SQLException {
		PreparedStatement requetePreparee = connection.prepareStatement(AuteurRequetes.DELETE);
		requetePreparee.setInt(1, id);
		return requetePreparee;
	}
}